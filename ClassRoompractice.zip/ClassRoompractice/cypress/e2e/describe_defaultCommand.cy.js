///<reference types="cypress"/>  //this shows references of the cypress commands
//@ts-check    //after adding this command, IDE can check the syntax of keywords
describe('a nice description', { defaultCommandTimeout: 10000 }, () => {
  it('should do an assert', { defaultCommandTimeout: 10000 }, () => {
    expect(1).to.equal(1);
  });
});