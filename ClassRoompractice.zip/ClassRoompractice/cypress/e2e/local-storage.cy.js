///<reference types="cypress" />
import('cypress-xpath')

describe('cypress local storage', () => {
  it('local storage example', () => {
    cy.visit('https://www.qrcode-monkey.com/').then(() =>{
      cy.xpath('//a[text()="Text"]').should('be.visible');
      cy.xpath('//h3[text()="Set Colors"]').should('be.visible')

      cy.xpath("//div[@class='type-bar-inner']/a").as('linkedelements');
      cy.get('@linkedelements').each((ele,index)=>{
        if (ele.text() =='Text')
        {
          console.log(ele.text());
          var elemet = ele.get(0);
          elemet.click();
          
        }
      //    //cy.wait
      //    //ele.trigger('click');
         
      })

      // cy.get('@linkedelements').click({ multiple: true });
      // cy.get('@linkedelements').click({
      //   shiftKey: true,
      // })
      

      // .each((element)=>{
          
      // })

      //       cy.log(localStorage.length);

      // localStorage.setItem('Cypress Example', 'Frankfurt');

      // cy.wait(2000).then(() => {
      //   localStorage.removeItem('Cypress Example');
      // })
      
    });

    //cy.get(".type-bar-inner").click();
  });
});