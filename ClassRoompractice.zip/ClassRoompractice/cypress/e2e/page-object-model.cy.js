///<reference types="cypress" />

import { Homepage } from "../../pageObjectModel/homepage";
const homepage = new Homepage();

describe('page object model', () => {
  it('page object mode example', () => {
    homepage.navigate();
  });
});
