///<reference types="cypress"/>  //this shows references of the cypress commands
//@ts-check    //after adding this command, IDE can check the syntax of keywords
describe('a nice description', () => {
  it('should do an assert', () => {
    expect(1).to.equal(1);
  });

  it.only('should be the only test to run', () => {
    expect(true).not.to.equal(false);
  });

  it.skip('should be skipped', () => {
    expect(true).not.to.equal(false);
  });

  // before(() => {
  //   cy.log('this command runs once before all tests within the describe-block');
  // });

  // beforeEach(() => {
  //   cy.log('this command runs before each test within the describe-block');
  // });

  afterEach(() => {
    cy.log('this command runs after each test within the describe-block');
  });

  after(() => {
    cy.log('this command runs once after all tests within the describe-block');
  });
});