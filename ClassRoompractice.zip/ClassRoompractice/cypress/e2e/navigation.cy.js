
describe('a nice description', () => {
  it('should visit the TabTracker', () => {
    cy.visit('http://google.com');
    cy.get('input[aria-label="Google Search"]',).should('be.visible');
});

it('should assert a search bar attribute', () => {
  cy.visit('http://google.com');
  cy.get('center').find('input')
    .should('be.visible')
    .should('have.attr','class','gNO89b')
    .should(
      'have.attr',
      'aria-label',
      'Google Search',
    );
});

it('should assert a search bar attribute', () => {
  cy.visit('http://google.com');
  cy.get('center').find('input')
    .should('be.visible')
    .should('have.attr','class','gNO89b')
    .should(
      'have.attr',
      'aria-label',
      'Google Search',
    );
});

});
