import { Given, When, Then, And } from "cypress-cucumber-preprocessor/steps";

Given("you navigate to this website", () => {
	cy.visit("https://www.qrcode-monkey.com");
})
When("you click on any page",()=>{
	cy.get('#onetrust-accept-btn-handler').click();
})
When("Validate you see new page landed upon",()=>{
	cy.contains('Add Logo Image').click();
})
