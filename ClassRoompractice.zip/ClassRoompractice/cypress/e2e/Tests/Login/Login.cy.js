//import {Given,When,Then,And} from ('cypress-cucumber-preprocessor/steps');
import { Given, When, Then, And } from "cypress-cucumber-preprocessor/steps";

Given("I navigate to the website", () => {
	cy.visit("http://automationpractice.com");
})
When("I enter user name and password",()=>{
	console.log("Entering password")
})
When("User click on sign in button",()=>{
	console.log("When User click on sign in button")
})
Then("Validate the title after login",()=>{
	console.log("Then Validate the title after login")
})
        
        
