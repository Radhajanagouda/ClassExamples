From Cypress.config residing folder we can run below command for running scripts in headless mode.

npx cypress run

path of documents
http://docs.learnandshine.in/cypress/handson/day2/